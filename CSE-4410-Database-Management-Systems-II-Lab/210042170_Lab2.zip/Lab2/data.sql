INSERT INTO Department (ID, Name) VALUES
  (1, 'Department1');
INSERT INTO Department (ID, Name) VALUES
  (2, 'Department2');
INSERT INTO Department (ID, Name) VALUES
  (3, 'Department3');
INSERT INTO Department (ID, Name) VALUES
  (4, 'Department4');
INSERT INTO Department (ID, Name) VALUES
  (5, 'Department5');
INSERT INTO Department (ID, Name) VALUES
  (6, 'Department6');
INSERT INTO Department (ID, Name) VALUES
  (7, 'Department7');
INSERT INTO Department (ID, Name) VALUES
  (8, 'Department8');
INSERT INTO Department (ID, Name) VALUES
  (9, 'Department9');
INSERT INTO Department (ID, Name) VALUES
  (10, 'Department10');
INSERT INTO Department (ID, Name) VALUES
  (11, 'Department11');
INSERT INTO Department (ID, Name) VALUES
  (12, 'Department12');
INSERT INTO Department (ID, Name) VALUES
  (13, 'Department13');
INSERT INTO Department (ID, Name) VALUES
  (14, 'Department14');
INSERT INTO Department (ID, Name) VALUES
  (15, 'Department15');
INSERT INTO Department (ID, Name) VALUES
  (16, 'Department16');
INSERT INTO Department (ID, Name) VALUES
  (17, 'Department17');
INSERT INTO Department (ID, Name) VALUES
  (18, 'Department18');
INSERT INTO Department (ID, Name) VALUES
  (19, 'Department19');
INSERT INTO Department (ID, Name) VALUES
  (20, 'Department20');


INSERT INTO Student (ID, name, dept_ID) VALUES
  (1, 'Student1', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (2, 'Student2', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (3, 'Student3', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (4, 'Student4', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (5, 'Student5', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (6, 'Student6', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (7, 'Student7', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (8, 'Student8', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (9, 'Student9', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (10, 'Student10', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (11, 'Student11', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (12, 'Student12', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (13, 'Student13', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (14, 'Student14', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (15, 'Student15', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (16, 'Student16', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (17, 'Student17', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (18, 'Student18', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (19, 'Student19', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (20, 'Student20', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (21, 'Student21', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (22, 'Student22', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (23, 'Student23', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (24, 'Student24', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (25, 'Student25', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (26, 'Student26', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (27, 'Student27', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (28, 'Student28', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (29, 'Student29', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (30, 'Student30', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (31, 'Student31', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (32, 'Student32', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (33, 'Student33', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (34, 'Student34', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (35, 'Student35', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (36, 'Student36', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (37, 'Student37', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (38, 'Student38', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (39, 'Student39', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (40, 'Student40', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (41, 'Student41', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (42, 'Student42', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (43, 'Student43', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (44, 'Student44', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (45, 'Student45', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (46, 'Student46', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (47, 'Student47', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (48, 'Student48', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (49, 'Student49', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (50, 'Student50', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (51, 'Student51', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (52, 'Student52', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (53, 'Student53', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (54, 'Student54', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (55, 'Student55', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (56, 'Student56', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (57, 'Student57', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (58, 'Student58', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (59, 'Student59', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (60, 'Student60', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (61, 'Student61', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (62, 'Student62', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (63, 'Student63', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (64, 'Student64', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (65, 'Student65', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (66, 'Student66', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (67, 'Student67', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (68, 'Student68', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (69, 'Student69', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (70, 'Student70', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (71, 'Student71', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (72, 'Student72', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (73, 'Student73', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (74, 'Student74', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (75, 'Student75', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (76, 'Student76', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (77, 'Student77', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (78, 'Student78', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (79, 'Student79', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (80, 'Student80', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (81, 'Student81', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (82, 'Student82', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (83, 'Student83', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (84, 'Student84', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (85, 'Student85', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (86, 'Student86', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (87, 'Student87', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (88, 'Student88', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (89, 'Student89', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (90, 'Student90', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (91, 'Student91', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (92, 'Student92', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (93, 'Student93', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (94, 'Student94', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (95, 'Student95', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (96, 'Student96', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (97, 'Student97', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (98, 'Student98', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (99, 'Student99', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (100, 'Student100', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (101, 'Student101', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (102, 'Student102', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (103, 'Student103', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (104, 'Student104', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (105, 'Student105', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (106, 'Student106', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (107, 'Student107', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (108, 'Student108', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (109, 'Student109', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (110, 'Student110', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (111, 'Student111', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (112, 'Student112', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (113, 'Student113', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (114, 'Student114', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (115, 'Student115', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (116, 'Student116', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (117, 'Student117', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (118, 'Student118', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (119, 'Student119', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (120, 'Student120', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (121, 'Student121', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (122, 'Student122', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (123, 'Student123', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (124, 'Student124', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (125, 'Student125', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (126, 'Student126', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (127, 'Student127', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (128, 'Student128', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (129, 'Student129', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (130, 'Student130', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (131, 'Student131', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (132, 'Student132', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (133, 'Student133', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (134, 'Student134', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (135, 'Student135', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (136, 'Student136', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (137, 'Student137', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (138, 'Student138', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (139, 'Student139', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (140, 'Student140', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (141, 'Student141', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (142, 'Student142', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (143, 'Student143', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (144, 'Student144', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (145, 'Student145', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (146, 'Student146', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (147, 'Student147', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (148, 'Student148', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (149, 'Student149', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (150, 'Student150', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (151, 'Student151', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (152, 'Student152', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (153, 'Student153', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (154, 'Student154', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (155, 'Student155', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (156, 'Student156', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (157, 'Student157', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (158, 'Student158', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (159, 'Student159', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (160, 'Student160', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (161, 'Student161', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (162, 'Student162', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (163, 'Student163', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (164, 'Student164', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (165, 'Student165', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (166, 'Student166', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (167, 'Student167', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (168, 'Student168', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (169, 'Student169', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (170, 'Student170', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (171, 'Student171', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (172, 'Student172', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (173, 'Student173', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (174, 'Student174', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (175, 'Student175', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (176, 'Student176', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (177, 'Student177', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (178, 'Student178', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (179, 'Student179', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (180, 'Student180', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (181, 'Student181', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (182, 'Student182', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (183, 'Student183', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (184, 'Student184', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (185, 'Student185', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (186, 'Student186', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (187, 'Student187', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (188, 'Student188', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (189, 'Student189', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (190, 'Student190', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (191, 'Student191', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (192, 'Student192', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (193, 'Student193', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (194, 'Student194', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (195, 'Student195', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (196, 'Student196', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (197, 'Student197', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (198, 'Student198', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (199, 'Student199', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (200, 'Student200', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (201, 'Student201', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (202, 'Student202', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (203, 'Student203', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (204, 'Student204', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (205, 'Student205', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (206, 'Student206', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (207, 'Student207', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (208, 'Student208', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (209, 'Student209', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (210, 'Student210', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (211, 'Student211', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (212, 'Student212', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (213, 'Student213', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (214, 'Student214', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (215, 'Student215', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (216, 'Student216', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (217, 'Student217', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (218, 'Student218', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (219, 'Student219', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (220, 'Student220', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (221, 'Student221', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (222, 'Student222', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (223, 'Student223', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (224, 'Student224', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (225, 'Student225', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (226, 'Student226', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (227, 'Student227', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (228, 'Student228', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (229, 'Student229', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (230, 'Student230', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (231, 'Student231', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (232, 'Student232', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (233, 'Student233', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (234, 'Student234', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (235, 'Student235', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (236, 'Student236', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (237, 'Student237', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (238, 'Student238', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (239, 'Student239', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (240, 'Student240', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (241, 'Student241', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (242, 'Student242', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (243, 'Student243', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (244, 'Student244', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (245, 'Student245', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (246, 'Student246', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (247, 'Student247', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (248, 'Student248', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (249, 'Student249', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (250, 'Student250', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (251, 'Student251', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (252, 'Student252', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (253, 'Student253', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (254, 'Student254', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (255, 'Student255', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (256, 'Student256', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (257, 'Student257', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (258, 'Student258', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (259, 'Student259', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (260, 'Student260', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (261, 'Student261', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (262, 'Student262', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (263, 'Student263', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (264, 'Student264', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (265, 'Student265', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (266, 'Student266', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (267, 'Student267', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (268, 'Student268', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (269, 'Student269', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (270, 'Student270', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (271, 'Student271', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (272, 'Student272', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (273, 'Student273', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (274, 'Student274', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (275, 'Student275', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (276, 'Student276', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (277, 'Student277', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (278, 'Student278', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (279, 'Student279', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (280, 'Student280', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (281, 'Student281', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (282, 'Student282', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (283, 'Student283', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (284, 'Student284', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (285, 'Student285', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (286, 'Student286', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (287, 'Student287', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (288, 'Student288', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (289, 'Student289', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (290, 'Student290', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (291, 'Student291', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (292, 'Student292', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (293, 'Student293', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (294, 'Student294', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (295, 'Student295', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (296, 'Student296', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (297, 'Student297', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (298, 'Student298', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (299, 'Student299', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (300, 'Student300', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (301, 'Student301', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (302, 'Student302', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (303, 'Student303', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (304, 'Student304', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (305, 'Student305', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (306, 'Student306', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (307, 'Student307', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (308, 'Student308', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (309, 'Student309', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (310, 'Student310', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (311, 'Student311', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (312, 'Student312', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (313, 'Student313', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (314, 'Student314', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (315, 'Student315', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (316, 'Student316', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (317, 'Student317', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (318, 'Student318', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (319, 'Student319', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (320, 'Student320', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (321, 'Student321', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (322, 'Student322', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (323, 'Student323', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (324, 'Student324', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (325, 'Student325', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (326, 'Student326', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (327, 'Student327', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (328, 'Student328', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (329, 'Student329', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (330, 'Student330', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (331, 'Student331', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (332, 'Student332', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (333, 'Student333', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (334, 'Student334', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (335, 'Student335', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (336, 'Student336', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (337, 'Student337', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (338, 'Student338', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (339, 'Student339', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (340, 'Student340', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (341, 'Student341', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (342, 'Student342', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (343, 'Student343', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (344, 'Student344', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (345, 'Student345', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (346, 'Student346', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (347, 'Student347', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (348, 'Student348', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (349, 'Student349', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (350, 'Student350', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (351, 'Student351', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (352, 'Student352', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (353, 'Student353', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (354, 'Student354', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (355, 'Student355', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (356, 'Student356', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (357, 'Student357', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (358, 'Student358', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (359, 'Student359', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (360, 'Student360', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (361, 'Student361', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (362, 'Student362', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (363, 'Student363', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (364, 'Student364', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (365, 'Student365', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (366, 'Student366', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (367, 'Student367', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (368, 'Student368', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (369, 'Student369', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (370, 'Student370', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (371, 'Student371', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (372, 'Student372', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (373, 'Student373', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (374, 'Student374', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (375, 'Student375', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (376, 'Student376', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (377, 'Student377', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (378, 'Student378', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (379, 'Student379', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (380, 'Student380', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (381, 'Student381', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (382, 'Student382', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (383, 'Student383', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (384, 'Student384', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (385, 'Student385', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (386, 'Student386', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (387, 'Student387', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (388, 'Student388', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (389, 'Student389', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (390, 'Student390', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (391, 'Student391', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (392, 'Student392', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (393, 'Student393', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (394, 'Student394', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (395, 'Student395', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (396, 'Student396', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (397, 'Student397', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (398, 'Student398', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (399, 'Student399', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (400, 'Student400', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (401, 'Student401', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (402, 'Student402', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (403, 'Student403', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (404, 'Student404', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (405, 'Student405', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (406, 'Student406', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (407, 'Student407', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (408, 'Student408', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (409, 'Student409', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (410, 'Student410', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (411, 'Student411', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (412, 'Student412', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (413, 'Student413', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (414, 'Student414', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (415, 'Student415', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (416, 'Student416', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (417, 'Student417', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (418, 'Student418', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (419, 'Student419', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (420, 'Student420', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (421, 'Student421', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (422, 'Student422', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (423, 'Student423', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (424, 'Student424', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (425, 'Student425', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (426, 'Student426', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (427, 'Student427', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (428, 'Student428', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (429, 'Student429', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (430, 'Student430', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (431, 'Student431', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (432, 'Student432', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (433, 'Student433', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (434, 'Student434', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (435, 'Student435', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (436, 'Student436', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (437, 'Student437', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (438, 'Student438', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (439, 'Student439', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (440, 'Student440', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (441, 'Student441', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (442, 'Student442', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (443, 'Student443', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (444, 'Student444', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (445, 'Student445', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (446, 'Student446', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (447, 'Student447', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (448, 'Student448', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (449, 'Student449', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (450, 'Student450', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (451, 'Student451', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (452, 'Student452', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (453, 'Student453', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (454, 'Student454', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (455, 'Student455', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (456, 'Student456', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (457, 'Student457', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (458, 'Student458', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (459, 'Student459', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (460, 'Student460', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (461, 'Student461', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (462, 'Student462', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (463, 'Student463', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (464, 'Student464', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (465, 'Student465', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (466, 'Student466', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (467, 'Student467', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (468, 'Student468', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (469, 'Student469', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (470, 'Student470', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (471, 'Student471', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (472, 'Student472', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (473, 'Student473', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (474, 'Student474', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (475, 'Student475', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (476, 'Student476', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (477, 'Student477', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (478, 'Student478', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (479, 'Student479', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (480, 'Student480', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (481, 'Student481', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (482, 'Student482', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (483, 'Student483', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (484, 'Student484', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (485, 'Student485', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (486, 'Student486', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (487, 'Student487', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (488, 'Student488', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (489, 'Student489', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (490, 'Student490', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (491, 'Student491', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (492, 'Student492', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (493, 'Student493', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (494, 'Student494', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (495, 'Student495', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (496, 'Student496', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (497, 'Student497', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (498, 'Student498', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (499, 'Student499', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (500, 'Student500', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (501, 'Student501', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (502, 'Student502', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (503, 'Student503', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (504, 'Student504', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (505, 'Student505', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (506, 'Student506', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (507, 'Student507', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (508, 'Student508', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (509, 'Student509', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (510, 'Student510', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (511, 'Student511', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (512, 'Student512', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (513, 'Student513', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (514, 'Student514', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (515, 'Student515', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (516, 'Student516', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (517, 'Student517', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (518, 'Student518', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (519, 'Student519', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (520, 'Student520', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (521, 'Student521', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (522, 'Student522', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (523, 'Student523', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (524, 'Student524', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (525, 'Student525', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (526, 'Student526', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (527, 'Student527', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (528, 'Student528', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (529, 'Student529', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (530, 'Student530', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (531, 'Student531', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (532, 'Student532', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (533, 'Student533', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (534, 'Student534', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (535, 'Student535', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (536, 'Student536', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (537, 'Student537', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (538, 'Student538', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (539, 'Student539', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (540, 'Student540', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (541, 'Student541', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (542, 'Student542', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (543, 'Student543', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (544, 'Student544', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (545, 'Student545', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (546, 'Student546', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (547, 'Student547', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (548, 'Student548', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (549, 'Student549', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (550, 'Student550', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (551, 'Student551', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (552, 'Student552', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (553, 'Student553', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (554, 'Student554', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (555, 'Student555', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (556, 'Student556', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (557, 'Student557', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (558, 'Student558', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (559, 'Student559', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (560, 'Student560', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (561, 'Student561', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (562, 'Student562', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (563, 'Student563', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (564, 'Student564', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (565, 'Student565', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (566, 'Student566', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (567, 'Student567', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (568, 'Student568', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (569, 'Student569', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (570, 'Student570', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (571, 'Student571', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (572, 'Student572', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (573, 'Student573', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (574, 'Student574', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (575, 'Student575', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (576, 'Student576', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (577, 'Student577', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (578, 'Student578', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (579, 'Student579', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (580, 'Student580', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (581, 'Student581', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (582, 'Student582', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (583, 'Student583', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (584, 'Student584', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (585, 'Student585', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (586, 'Student586', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (587, 'Student587', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (588, 'Student588', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (589, 'Student589', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (590, 'Student590', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (591, 'Student591', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (592, 'Student592', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (593, 'Student593', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (594, 'Student594', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (595, 'Student595', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (596, 'Student596', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (597, 'Student597', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (598, 'Student598', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (599, 'Student599', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (600, 'Student600', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (601, 'Student601', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (602, 'Student602', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (603, 'Student603', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (604, 'Student604', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (605, 'Student605', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (606, 'Student606', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (607, 'Student607', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (608, 'Student608', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (609, 'Student609', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (610, 'Student610', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (611, 'Student611', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (612, 'Student612', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (613, 'Student613', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (614, 'Student614', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (615, 'Student615', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (616, 'Student616', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (617, 'Student617', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (618, 'Student618', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (619, 'Student619', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (620, 'Student620', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (621, 'Student621', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (622, 'Student622', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (623, 'Student623', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (624, 'Student624', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (625, 'Student625', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (626, 'Student626', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (627, 'Student627', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (628, 'Student628', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (629, 'Student629', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (630, 'Student630', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (631, 'Student631', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (632, 'Student632', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (633, 'Student633', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (634, 'Student634', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (635, 'Student635', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (636, 'Student636', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (637, 'Student637', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (638, 'Student638', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (639, 'Student639', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (640, 'Student640', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (641, 'Student641', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (642, 'Student642', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (643, 'Student643', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (644, 'Student644', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (645, 'Student645', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (646, 'Student646', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (647, 'Student647', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (648, 'Student648', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (649, 'Student649', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (650, 'Student650', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (651, 'Student651', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (652, 'Student652', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (653, 'Student653', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (654, 'Student654', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (655, 'Student655', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (656, 'Student656', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (657, 'Student657', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (658, 'Student658', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (659, 'Student659', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (660, 'Student660', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (661, 'Student661', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (662, 'Student662', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (663, 'Student663', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (664, 'Student664', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (665, 'Student665', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (666, 'Student666', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (667, 'Student667', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (668, 'Student668', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (669, 'Student669', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (670, 'Student670', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (671, 'Student671', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (672, 'Student672', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (673, 'Student673', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (674, 'Student674', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (675, 'Student675', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (676, 'Student676', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (677, 'Student677', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (678, 'Student678', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (679, 'Student679', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (680, 'Student680', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (681, 'Student681', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (682, 'Student682', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (683, 'Student683', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (684, 'Student684', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (685, 'Student685', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (686, 'Student686', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (687, 'Student687', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (688, 'Student688', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (689, 'Student689', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (690, 'Student690', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (691, 'Student691', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (692, 'Student692', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (693, 'Student693', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (694, 'Student694', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (695, 'Student695', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (696, 'Student696', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (697, 'Student697', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (698, 'Student698', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (699, 'Student699', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (700, 'Student700', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (701, 'Student701', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (702, 'Student702', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (703, 'Student703', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (704, 'Student704', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (705, 'Student705', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (706, 'Student706', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (707, 'Student707', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (708, 'Student708', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (709, 'Student709', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (710, 'Student710', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (711, 'Student711', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (712, 'Student712', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (713, 'Student713', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (714, 'Student714', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (715, 'Student715', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (716, 'Student716', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (717, 'Student717', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (718, 'Student718', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (719, 'Student719', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (720, 'Student720', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (721, 'Student721', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (722, 'Student722', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (723, 'Student723', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (724, 'Student724', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (725, 'Student725', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (726, 'Student726', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (727, 'Student727', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (728, 'Student728', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (729, 'Student729', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (730, 'Student730', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (731, 'Student731', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (732, 'Student732', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (733, 'Student733', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (734, 'Student734', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (735, 'Student735', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (736, 'Student736', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (737, 'Student737', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (738, 'Student738', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (739, 'Student739', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (740, 'Student740', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (741, 'Student741', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (742, 'Student742', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (743, 'Student743', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (744, 'Student744', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (745, 'Student745', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (746, 'Student746', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (747, 'Student747', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (748, 'Student748', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (749, 'Student749', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (750, 'Student750', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (751, 'Student751', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (752, 'Student752', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (753, 'Student753', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (754, 'Student754', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (755, 'Student755', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (756, 'Student756', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (757, 'Student757', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (758, 'Student758', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (759, 'Student759', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (760, 'Student760', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (761, 'Student761', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (762, 'Student762', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (763, 'Student763', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (764, 'Student764', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (765, 'Student765', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (766, 'Student766', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (767, 'Student767', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (768, 'Student768', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (769, 'Student769', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (770, 'Student770', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (771, 'Student771', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (772, 'Student772', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (773, 'Student773', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (774, 'Student774', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (775, 'Student775', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (776, 'Student776', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (777, 'Student777', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (778, 'Student778', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (779, 'Student779', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (780, 'Student780', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (781, 'Student781', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (782, 'Student782', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (783, 'Student783', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (784, 'Student784', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (785, 'Student785', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (786, 'Student786', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (787, 'Student787', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (788, 'Student788', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (789, 'Student789', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (790, 'Student790', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (791, 'Student791', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (792, 'Student792', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (793, 'Student793', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (794, 'Student794', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (795, 'Student795', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (796, 'Student796', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (797, 'Student797', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (798, 'Student798', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (799, 'Student799', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (800, 'Student800', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (801, 'Student801', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (802, 'Student802', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (803, 'Student803', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (804, 'Student804', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (805, 'Student805', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (806, 'Student806', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (807, 'Student807', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (808, 'Student808', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (809, 'Student809', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (810, 'Student810', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (811, 'Student811', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (812, 'Student812', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (813, 'Student813', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (814, 'Student814', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (815, 'Student815', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (816, 'Student816', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (817, 'Student817', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (818, 'Student818', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (819, 'Student819', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (820, 'Student820', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (821, 'Student821', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (822, 'Student822', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (823, 'Student823', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (824, 'Student824', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (825, 'Student825', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (826, 'Student826', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (827, 'Student827', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (828, 'Student828', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (829, 'Student829', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (830, 'Student830', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (831, 'Student831', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (832, 'Student832', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (833, 'Student833', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (834, 'Student834', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (835, 'Student835', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (836, 'Student836', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (837, 'Student837', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (838, 'Student838', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (839, 'Student839', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (840, 'Student840', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (841, 'Student841', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (842, 'Student842', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (843, 'Student843', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (844, 'Student844', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (845, 'Student845', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (846, 'Student846', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (847, 'Student847', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (848, 'Student848', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (849, 'Student849', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (850, 'Student850', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (851, 'Student851', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (852, 'Student852', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (853, 'Student853', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (854, 'Student854', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (855, 'Student855', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (856, 'Student856', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (857, 'Student857', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (858, 'Student858', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (859, 'Student859', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (860, 'Student860', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (861, 'Student861', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (862, 'Student862', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (863, 'Student863', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (864, 'Student864', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (865, 'Student865', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (866, 'Student866', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (867, 'Student867', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (868, 'Student868', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (869, 'Student869', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (870, 'Student870', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (871, 'Student871', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (872, 'Student872', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (873, 'Student873', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (874, 'Student874', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (875, 'Student875', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (876, 'Student876', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (877, 'Student877', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (878, 'Student878', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (879, 'Student879', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (880, 'Student880', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (881, 'Student881', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (882, 'Student882', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (883, 'Student883', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (884, 'Student884', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (885, 'Student885', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (886, 'Student886', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (887, 'Student887', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (888, 'Student888', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (889, 'Student889', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (890, 'Student890', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (891, 'Student891', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (892, 'Student892', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (893, 'Student893', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (894, 'Student894', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (895, 'Student895', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (896, 'Student896', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (897, 'Student897', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (898, 'Student898', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (899, 'Student899', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (900, 'Student900', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (901, 'Student901', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (902, 'Student902', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (903, 'Student903', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (904, 'Student904', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (905, 'Student905', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (906, 'Student906', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (907, 'Student907', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (908, 'Student908', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (909, 'Student909', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (910, 'Student910', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (911, 'Student911', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (912, 'Student912', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (913, 'Student913', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (914, 'Student914', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (915, 'Student915', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (916, 'Student916', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (917, 'Student917', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (918, 'Student918', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (919, 'Student919', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (920, 'Student920', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (921, 'Student921', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (922, 'Student922', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (923, 'Student923', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (924, 'Student924', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (925, 'Student925', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (926, 'Student926', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (927, 'Student927', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (928, 'Student928', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (929, 'Student929', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (930, 'Student930', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (931, 'Student931', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (932, 'Student932', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (933, 'Student933', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (934, 'Student934', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (935, 'Student935', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (936, 'Student936', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (937, 'Student937', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (938, 'Student938', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (939, 'Student939', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (940, 'Student940', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (941, 'Student941', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (942, 'Student942', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (943, 'Student943', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (944, 'Student944', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (945, 'Student945', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (946, 'Student946', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (947, 'Student947', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (948, 'Student948', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (949, 'Student949', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (950, 'Student950', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (951, 'Student951', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (952, 'Student952', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (953, 'Student953', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (954, 'Student954', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (955, 'Student955', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (956, 'Student956', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (957, 'Student957', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (958, 'Student958', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (959, 'Student959', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (960, 'Student960', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (961, 'Student961', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (962, 'Student962', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (963, 'Student963', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (964, 'Student964', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (965, 'Student965', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (966, 'Student966', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (967, 'Student967', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (968, 'Student968', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (969, 'Student969', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (970, 'Student970', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (971, 'Student971', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (972, 'Student972', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (973, 'Student973', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (974, 'Student974', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (975, 'Student975', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (976, 'Student976', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (977, 'Student977', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (978, 'Student978', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (979, 'Student979', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (980, 'Student980', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (981, 'Student981', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (982, 'Student982', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (983, 'Student983', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (984, 'Student984', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (985, 'Student985', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (986, 'Student986', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (987, 'Student987', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (988, 'Student988', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (989, 'Student989', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (990, 'Student990', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (991, 'Student991', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (992, 'Student992', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (993, 'Student993', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (994, 'Student994', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (995, 'Student995', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (996, 'Student996', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (997, 'Student997', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (998, 'Student998', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (999, 'Student999', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1000, 'Student1000', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1001, 'Student1001', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1002, 'Student1002', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1003, 'Student1003', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1004, 'Student1004', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1005, 'Student1005', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1006, 'Student1006', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1007, 'Student1007', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1008, 'Student1008', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1009, 'Student1009', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1010, 'Student1010', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1011, 'Student1011', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1012, 'Student1012', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1013, 'Student1013', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1014, 'Student1014', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1015, 'Student1015', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1016, 'Student1016', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1017, 'Student1017', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1018, 'Student1018', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1019, 'Student1019', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1020, 'Student1020', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1021, 'Student1021', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1022, 'Student1022', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1023, 'Student1023', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1024, 'Student1024', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1025, 'Student1025', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1026, 'Student1026', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1027, 'Student1027', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1028, 'Student1028', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1029, 'Student1029', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1030, 'Student1030', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1031, 'Student1031', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1032, 'Student1032', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1033, 'Student1033', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1034, 'Student1034', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1035, 'Student1035', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1036, 'Student1036', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1037, 'Student1037', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1038, 'Student1038', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1039, 'Student1039', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1040, 'Student1040', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1041, 'Student1041', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1042, 'Student1042', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1043, 'Student1043', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1044, 'Student1044', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1045, 'Student1045', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1046, 'Student1046', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1047, 'Student1047', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1048, 'Student1048', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1049, 'Student1049', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1050, 'Student1050', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1051, 'Student1051', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1052, 'Student1052', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1053, 'Student1053', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1054, 'Student1054', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1055, 'Student1055', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1056, 'Student1056', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1057, 'Student1057', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1058, 'Student1058', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1059, 'Student1059', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1060, 'Student1060', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1061, 'Student1061', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1062, 'Student1062', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1063, 'Student1063', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1064, 'Student1064', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1065, 'Student1065', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1066, 'Student1066', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1067, 'Student1067', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1068, 'Student1068', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1069, 'Student1069', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1070, 'Student1070', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1071, 'Student1071', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1072, 'Student1072', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1073, 'Student1073', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1074, 'Student1074', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1075, 'Student1075', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1076, 'Student1076', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1077, 'Student1077', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1078, 'Student1078', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1079, 'Student1079', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1080, 'Student1080', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1081, 'Student1081', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1082, 'Student1082', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1083, 'Student1083', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1084, 'Student1084', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1085, 'Student1085', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1086, 'Student1086', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1087, 'Student1087', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1088, 'Student1088', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1089, 'Student1089', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1090, 'Student1090', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1091, 'Student1091', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1092, 'Student1092', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1093, 'Student1093', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1094, 'Student1094', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1095, 'Student1095', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1096, 'Student1096', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1097, 'Student1097', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1098, 'Student1098', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1099, 'Student1099', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1100, 'Student1100', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1101, 'Student1101', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1102, 'Student1102', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1103, 'Student1103', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1104, 'Student1104', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1105, 'Student1105', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1106, 'Student1106', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1107, 'Student1107', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1108, 'Student1108', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1109, 'Student1109', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1110, 'Student1110', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1111, 'Student1111', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1112, 'Student1112', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1113, 'Student1113', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1114, 'Student1114', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1115, 'Student1115', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1116, 'Student1116', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1117, 'Student1117', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1118, 'Student1118', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1119, 'Student1119', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1120, 'Student1120', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1121, 'Student1121', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1122, 'Student1122', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1123, 'Student1123', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1124, 'Student1124', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1125, 'Student1125', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1126, 'Student1126', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1127, 'Student1127', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1128, 'Student1128', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1129, 'Student1129', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1130, 'Student1130', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1131, 'Student1131', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1132, 'Student1132', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1133, 'Student1133', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1134, 'Student1134', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1135, 'Student1135', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1136, 'Student1136', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1137, 'Student1137', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1138, 'Student1138', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1139, 'Student1139', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1140, 'Student1140', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1141, 'Student1141', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1142, 'Student1142', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1143, 'Student1143', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1144, 'Student1144', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1145, 'Student1145', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1146, 'Student1146', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1147, 'Student1147', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1148, 'Student1148', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1149, 'Student1149', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1150, 'Student1150', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1151, 'Student1151', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1152, 'Student1152', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1153, 'Student1153', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1154, 'Student1154', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1155, 'Student1155', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1156, 'Student1156', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1157, 'Student1157', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1158, 'Student1158', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1159, 'Student1159', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1160, 'Student1160', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1161, 'Student1161', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1162, 'Student1162', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1163, 'Student1163', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1164, 'Student1164', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1165, 'Student1165', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1166, 'Student1166', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1167, 'Student1167', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1168, 'Student1168', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1169, 'Student1169', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1170, 'Student1170', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1171, 'Student1171', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1172, 'Student1172', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1173, 'Student1173', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1174, 'Student1174', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1175, 'Student1175', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1176, 'Student1176', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1177, 'Student1177', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1178, 'Student1178', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1179, 'Student1179', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1180, 'Student1180', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1181, 'Student1181', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1182, 'Student1182', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1183, 'Student1183', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1184, 'Student1184', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1185, 'Student1185', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1186, 'Student1186', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1187, 'Student1187', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1188, 'Student1188', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1189, 'Student1189', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1190, 'Student1190', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1191, 'Student1191', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1192, 'Student1192', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1193, 'Student1193', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1194, 'Student1194', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1195, 'Student1195', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1196, 'Student1196', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1197, 'Student1197', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1198, 'Student1198', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1199, 'Student1199', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1200, 'Student1200', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1201, 'Student1201', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1202, 'Student1202', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1203, 'Student1203', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1204, 'Student1204', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1205, 'Student1205', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1206, 'Student1206', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1207, 'Student1207', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1208, 'Student1208', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1209, 'Student1209', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1210, 'Student1210', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1211, 'Student1211', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1212, 'Student1212', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1213, 'Student1213', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1214, 'Student1214', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1215, 'Student1215', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1216, 'Student1216', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1217, 'Student1217', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1218, 'Student1218', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1219, 'Student1219', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1220, 'Student1220', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1221, 'Student1221', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1222, 'Student1222', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1223, 'Student1223', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1224, 'Student1224', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1225, 'Student1225', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1226, 'Student1226', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1227, 'Student1227', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1228, 'Student1228', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1229, 'Student1229', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1230, 'Student1230', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1231, 'Student1231', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1232, 'Student1232', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1233, 'Student1233', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1234, 'Student1234', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1235, 'Student1235', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1236, 'Student1236', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1237, 'Student1237', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1238, 'Student1238', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1239, 'Student1239', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1240, 'Student1240', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1241, 'Student1241', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1242, 'Student1242', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1243, 'Student1243', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1244, 'Student1244', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1245, 'Student1245', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1246, 'Student1246', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1247, 'Student1247', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1248, 'Student1248', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1249, 'Student1249', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1250, 'Student1250', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1251, 'Student1251', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1252, 'Student1252', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1253, 'Student1253', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1254, 'Student1254', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1255, 'Student1255', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1256, 'Student1256', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1257, 'Student1257', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1258, 'Student1258', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1259, 'Student1259', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1260, 'Student1260', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1261, 'Student1261', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1262, 'Student1262', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1263, 'Student1263', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1264, 'Student1264', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1265, 'Student1265', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1266, 'Student1266', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1267, 'Student1267', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1268, 'Student1268', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1269, 'Student1269', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1270, 'Student1270', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1271, 'Student1271', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1272, 'Student1272', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1273, 'Student1273', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1274, 'Student1274', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1275, 'Student1275', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1276, 'Student1276', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1277, 'Student1277', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1278, 'Student1278', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1279, 'Student1279', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1280, 'Student1280', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1281, 'Student1281', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1282, 'Student1282', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1283, 'Student1283', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1284, 'Student1284', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1285, 'Student1285', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1286, 'Student1286', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1287, 'Student1287', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1288, 'Student1288', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1289, 'Student1289', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1290, 'Student1290', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1291, 'Student1291', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1292, 'Student1292', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1293, 'Student1293', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1294, 'Student1294', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1295, 'Student1295', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1296, 'Student1296', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1297, 'Student1297', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1298, 'Student1298', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1299, 'Student1299', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1300, 'Student1300', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1301, 'Student1301', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1302, 'Student1302', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1303, 'Student1303', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1304, 'Student1304', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1305, 'Student1305', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1306, 'Student1306', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1307, 'Student1307', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1308, 'Student1308', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1309, 'Student1309', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1310, 'Student1310', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1311, 'Student1311', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1312, 'Student1312', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1313, 'Student1313', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1314, 'Student1314', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1315, 'Student1315', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1316, 'Student1316', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1317, 'Student1317', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1318, 'Student1318', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1319, 'Student1319', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1320, 'Student1320', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1321, 'Student1321', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1322, 'Student1322', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1323, 'Student1323', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1324, 'Student1324', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1325, 'Student1325', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1326, 'Student1326', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1327, 'Student1327', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1328, 'Student1328', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1329, 'Student1329', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1330, 'Student1330', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1331, 'Student1331', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1332, 'Student1332', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1333, 'Student1333', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1334, 'Student1334', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1335, 'Student1335', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1336, 'Student1336', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1337, 'Student1337', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1338, 'Student1338', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1339, 'Student1339', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1340, 'Student1340', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1341, 'Student1341', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1342, 'Student1342', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1343, 'Student1343', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1344, 'Student1344', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1345, 'Student1345', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1346, 'Student1346', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1347, 'Student1347', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1348, 'Student1348', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1349, 'Student1349', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1350, 'Student1350', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1351, 'Student1351', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1352, 'Student1352', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1353, 'Student1353', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1354, 'Student1354', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1355, 'Student1355', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1356, 'Student1356', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1357, 'Student1357', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1358, 'Student1358', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1359, 'Student1359', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1360, 'Student1360', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1361, 'Student1361', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1362, 'Student1362', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1363, 'Student1363', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1364, 'Student1364', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1365, 'Student1365', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1366, 'Student1366', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1367, 'Student1367', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1368, 'Student1368', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1369, 'Student1369', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1370, 'Student1370', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1371, 'Student1371', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1372, 'Student1372', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1373, 'Student1373', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1374, 'Student1374', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1375, 'Student1375', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1376, 'Student1376', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1377, 'Student1377', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1378, 'Student1378', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1379, 'Student1379', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1380, 'Student1380', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1381, 'Student1381', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1382, 'Student1382', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1383, 'Student1383', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1384, 'Student1384', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1385, 'Student1385', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1386, 'Student1386', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1387, 'Student1387', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1388, 'Student1388', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1389, 'Student1389', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1390, 'Student1390', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1391, 'Student1391', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1392, 'Student1392', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1393, 'Student1393', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1394, 'Student1394', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1395, 'Student1395', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1396, 'Student1396', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1397, 'Student1397', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1398, 'Student1398', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1399, 'Student1399', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1400, 'Student1400', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1401, 'Student1401', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1402, 'Student1402', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1403, 'Student1403', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1404, 'Student1404', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1405, 'Student1405', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1406, 'Student1406', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1407, 'Student1407', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1408, 'Student1408', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1409, 'Student1409', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1410, 'Student1410', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1411, 'Student1411', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1412, 'Student1412', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1413, 'Student1413', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1414, 'Student1414', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1415, 'Student1415', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1416, 'Student1416', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1417, 'Student1417', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1418, 'Student1418', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1419, 'Student1419', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1420, 'Student1420', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1421, 'Student1421', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1422, 'Student1422', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1423, 'Student1423', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1424, 'Student1424', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1425, 'Student1425', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1426, 'Student1426', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1427, 'Student1427', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1428, 'Student1428', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1429, 'Student1429', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1430, 'Student1430', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1431, 'Student1431', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1432, 'Student1432', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1433, 'Student1433', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1434, 'Student1434', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1435, 'Student1435', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1436, 'Student1436', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1437, 'Student1437', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1438, 'Student1438', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1439, 'Student1439', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1440, 'Student1440', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1441, 'Student1441', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1442, 'Student1442', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1443, 'Student1443', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1444, 'Student1444', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1445, 'Student1445', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1446, 'Student1446', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1447, 'Student1447', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1448, 'Student1448', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1449, 'Student1449', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1450, 'Student1450', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1451, 'Student1451', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1452, 'Student1452', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1453, 'Student1453', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1454, 'Student1454', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1455, 'Student1455', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1456, 'Student1456', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1457, 'Student1457', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1458, 'Student1458', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1459, 'Student1459', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1460, 'Student1460', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1461, 'Student1461', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1462, 'Student1462', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1463, 'Student1463', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1464, 'Student1464', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1465, 'Student1465', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1466, 'Student1466', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1467, 'Student1467', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1468, 'Student1468', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1469, 'Student1469', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1470, 'Student1470', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1471, 'Student1471', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1472, 'Student1472', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1473, 'Student1473', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1474, 'Student1474', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1475, 'Student1475', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1476, 'Student1476', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1477, 'Student1477', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1478, 'Student1478', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1479, 'Student1479', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1480, 'Student1480', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1481, 'Student1481', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1482, 'Student1482', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1483, 'Student1483', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1484, 'Student1484', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1485, 'Student1485', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1486, 'Student1486', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1487, 'Student1487', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1488, 'Student1488', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1489, 'Student1489', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1490, 'Student1490', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1491, 'Student1491', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1492, 'Student1492', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1493, 'Student1493', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1494, 'Student1494', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1495, 'Student1495', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1496, 'Student1496', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1497, 'Student1497', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1498, 'Student1498', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1499, 'Student1499', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1500, 'Student1500', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1501, 'Student1501', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1502, 'Student1502', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1503, 'Student1503', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1504, 'Student1504', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1505, 'Student1505', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1506, 'Student1506', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1507, 'Student1507', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1508, 'Student1508', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1509, 'Student1509', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1510, 'Student1510', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1511, 'Student1511', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1512, 'Student1512', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1513, 'Student1513', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1514, 'Student1514', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1515, 'Student1515', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1516, 'Student1516', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1517, 'Student1517', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1518, 'Student1518', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1519, 'Student1519', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1520, 'Student1520', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1521, 'Student1521', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1522, 'Student1522', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1523, 'Student1523', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1524, 'Student1524', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1525, 'Student1525', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1526, 'Student1526', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1527, 'Student1527', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1528, 'Student1528', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1529, 'Student1529', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1530, 'Student1530', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1531, 'Student1531', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1532, 'Student1532', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1533, 'Student1533', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1534, 'Student1534', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1535, 'Student1535', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1536, 'Student1536', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1537, 'Student1537', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1538, 'Student1538', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1539, 'Student1539', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1540, 'Student1540', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1541, 'Student1541', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1542, 'Student1542', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1543, 'Student1543', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1544, 'Student1544', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1545, 'Student1545', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1546, 'Student1546', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1547, 'Student1547', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1548, 'Student1548', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1549, 'Student1549', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1550, 'Student1550', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1551, 'Student1551', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1552, 'Student1552', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1553, 'Student1553', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1554, 'Student1554', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1555, 'Student1555', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1556, 'Student1556', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1557, 'Student1557', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1558, 'Student1558', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1559, 'Student1559', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1560, 'Student1560', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1561, 'Student1561', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1562, 'Student1562', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1563, 'Student1563', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1564, 'Student1564', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1565, 'Student1565', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1566, 'Student1566', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1567, 'Student1567', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1568, 'Student1568', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1569, 'Student1569', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1570, 'Student1570', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1571, 'Student1571', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1572, 'Student1572', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1573, 'Student1573', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1574, 'Student1574', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1575, 'Student1575', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1576, 'Student1576', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1577, 'Student1577', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1578, 'Student1578', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1579, 'Student1579', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1580, 'Student1580', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1581, 'Student1581', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1582, 'Student1582', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1583, 'Student1583', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1584, 'Student1584', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1585, 'Student1585', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1586, 'Student1586', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1587, 'Student1587', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1588, 'Student1588', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1589, 'Student1589', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1590, 'Student1590', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1591, 'Student1591', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1592, 'Student1592', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1593, 'Student1593', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1594, 'Student1594', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1595, 'Student1595', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1596, 'Student1596', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1597, 'Student1597', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1598, 'Student1598', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1599, 'Student1599', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1600, 'Student1600', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1601, 'Student1601', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1602, 'Student1602', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1603, 'Student1603', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1604, 'Student1604', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1605, 'Student1605', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1606, 'Student1606', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1607, 'Student1607', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1608, 'Student1608', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1609, 'Student1609', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1610, 'Student1610', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1611, 'Student1611', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1612, 'Student1612', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1613, 'Student1613', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1614, 'Student1614', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1615, 'Student1615', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1616, 'Student1616', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1617, 'Student1617', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1618, 'Student1618', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1619, 'Student1619', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1620, 'Student1620', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1621, 'Student1621', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1622, 'Student1622', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1623, 'Student1623', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1624, 'Student1624', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1625, 'Student1625', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1626, 'Student1626', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1627, 'Student1627', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1628, 'Student1628', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1629, 'Student1629', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1630, 'Student1630', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1631, 'Student1631', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1632, 'Student1632', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1633, 'Student1633', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1634, 'Student1634', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1635, 'Student1635', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1636, 'Student1636', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1637, 'Student1637', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1638, 'Student1638', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1639, 'Student1639', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1640, 'Student1640', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1641, 'Student1641', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1642, 'Student1642', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1643, 'Student1643', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1644, 'Student1644', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1645, 'Student1645', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1646, 'Student1646', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1647, 'Student1647', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1648, 'Student1648', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1649, 'Student1649', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1650, 'Student1650', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1651, 'Student1651', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1652, 'Student1652', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1653, 'Student1653', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1654, 'Student1654', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1655, 'Student1655', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1656, 'Student1656', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1657, 'Student1657', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1658, 'Student1658', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1659, 'Student1659', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1660, 'Student1660', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1661, 'Student1661', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1662, 'Student1662', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1663, 'Student1663', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1664, 'Student1664', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1665, 'Student1665', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1666, 'Student1666', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1667, 'Student1667', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1668, 'Student1668', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1669, 'Student1669', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1670, 'Student1670', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1671, 'Student1671', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1672, 'Student1672', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1673, 'Student1673', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1674, 'Student1674', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1675, 'Student1675', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1676, 'Student1676', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1677, 'Student1677', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1678, 'Student1678', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1679, 'Student1679', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1680, 'Student1680', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1681, 'Student1681', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1682, 'Student1682', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1683, 'Student1683', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1684, 'Student1684', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1685, 'Student1685', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1686, 'Student1686', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1687, 'Student1687', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1688, 'Student1688', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1689, 'Student1689', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1690, 'Student1690', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1691, 'Student1691', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1692, 'Student1692', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1693, 'Student1693', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1694, 'Student1694', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1695, 'Student1695', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1696, 'Student1696', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1697, 'Student1697', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1698, 'Student1698', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1699, 'Student1699', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1700, 'Student1700', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1701, 'Student1701', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1702, 'Student1702', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1703, 'Student1703', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1704, 'Student1704', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1705, 'Student1705', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1706, 'Student1706', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1707, 'Student1707', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1708, 'Student1708', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1709, 'Student1709', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1710, 'Student1710', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1711, 'Student1711', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1712, 'Student1712', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1713, 'Student1713', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1714, 'Student1714', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1715, 'Student1715', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1716, 'Student1716', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1717, 'Student1717', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1718, 'Student1718', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1719, 'Student1719', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1720, 'Student1720', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1721, 'Student1721', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1722, 'Student1722', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1723, 'Student1723', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1724, 'Student1724', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1725, 'Student1725', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1726, 'Student1726', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1727, 'Student1727', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1728, 'Student1728', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1729, 'Student1729', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1730, 'Student1730', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1731, 'Student1731', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1732, 'Student1732', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1733, 'Student1733', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1734, 'Student1734', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1735, 'Student1735', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1736, 'Student1736', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1737, 'Student1737', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1738, 'Student1738', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1739, 'Student1739', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1740, 'Student1740', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1741, 'Student1741', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1742, 'Student1742', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1743, 'Student1743', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1744, 'Student1744', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1745, 'Student1745', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1746, 'Student1746', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1747, 'Student1747', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1748, 'Student1748', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1749, 'Student1749', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1750, 'Student1750', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1751, 'Student1751', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1752, 'Student1752', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1753, 'Student1753', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1754, 'Student1754', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1755, 'Student1755', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1756, 'Student1756', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1757, 'Student1757', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1758, 'Student1758', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1759, 'Student1759', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1760, 'Student1760', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1761, 'Student1761', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1762, 'Student1762', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1763, 'Student1763', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1764, 'Student1764', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1765, 'Student1765', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1766, 'Student1766', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1767, 'Student1767', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1768, 'Student1768', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1769, 'Student1769', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1770, 'Student1770', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1771, 'Student1771', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1772, 'Student1772', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1773, 'Student1773', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1774, 'Student1774', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1775, 'Student1775', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1776, 'Student1776', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1777, 'Student1777', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1778, 'Student1778', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1779, 'Student1779', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1780, 'Student1780', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1781, 'Student1781', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1782, 'Student1782', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1783, 'Student1783', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1784, 'Student1784', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1785, 'Student1785', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1786, 'Student1786', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1787, 'Student1787', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1788, 'Student1788', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1789, 'Student1789', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1790, 'Student1790', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1791, 'Student1791', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1792, 'Student1792', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1793, 'Student1793', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1794, 'Student1794', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1795, 'Student1795', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1796, 'Student1796', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1797, 'Student1797', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1798, 'Student1798', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1799, 'Student1799', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1800, 'Student1800', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1801, 'Student1801', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1802, 'Student1802', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1803, 'Student1803', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1804, 'Student1804', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1805, 'Student1805', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1806, 'Student1806', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1807, 'Student1807', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1808, 'Student1808', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1809, 'Student1809', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1810, 'Student1810', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1811, 'Student1811', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1812, 'Student1812', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1813, 'Student1813', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1814, 'Student1814', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1815, 'Student1815', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1816, 'Student1816', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1817, 'Student1817', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1818, 'Student1818', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1819, 'Student1819', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1820, 'Student1820', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1821, 'Student1821', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1822, 'Student1822', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1823, 'Student1823', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1824, 'Student1824', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1825, 'Student1825', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1826, 'Student1826', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1827, 'Student1827', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1828, 'Student1828', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1829, 'Student1829', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1830, 'Student1830', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1831, 'Student1831', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1832, 'Student1832', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1833, 'Student1833', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1834, 'Student1834', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1835, 'Student1835', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1836, 'Student1836', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1837, 'Student1837', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1838, 'Student1838', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1839, 'Student1839', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1840, 'Student1840', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1841, 'Student1841', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1842, 'Student1842', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1843, 'Student1843', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1844, 'Student1844', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1845, 'Student1845', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1846, 'Student1846', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1847, 'Student1847', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1848, 'Student1848', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1849, 'Student1849', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1850, 'Student1850', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1851, 'Student1851', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1852, 'Student1852', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1853, 'Student1853', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1854, 'Student1854', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1855, 'Student1855', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1856, 'Student1856', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1857, 'Student1857', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1858, 'Student1858', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1859, 'Student1859', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1860, 'Student1860', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1861, 'Student1861', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1862, 'Student1862', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1863, 'Student1863', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1864, 'Student1864', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1865, 'Student1865', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1866, 'Student1866', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1867, 'Student1867', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1868, 'Student1868', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1869, 'Student1869', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1870, 'Student1870', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1871, 'Student1871', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1872, 'Student1872', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1873, 'Student1873', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1874, 'Student1874', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1875, 'Student1875', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1876, 'Student1876', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1877, 'Student1877', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1878, 'Student1878', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1879, 'Student1879', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1880, 'Student1880', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1881, 'Student1881', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1882, 'Student1882', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1883, 'Student1883', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1884, 'Student1884', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1885, 'Student1885', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1886, 'Student1886', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1887, 'Student1887', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1888, 'Student1888', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1889, 'Student1889', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1890, 'Student1890', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1891, 'Student1891', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1892, 'Student1892', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1893, 'Student1893', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1894, 'Student1894', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1895, 'Student1895', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1896, 'Student1896', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1897, 'Student1897', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1898, 'Student1898', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1899, 'Student1899', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1900, 'Student1900', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1901, 'Student1901', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1902, 'Student1902', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1903, 'Student1903', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1904, 'Student1904', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1905, 'Student1905', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1906, 'Student1906', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1907, 'Student1907', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1908, 'Student1908', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1909, 'Student1909', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1910, 'Student1910', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1911, 'Student1911', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1912, 'Student1912', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1913, 'Student1913', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1914, 'Student1914', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1915, 'Student1915', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1916, 'Student1916', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1917, 'Student1917', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1918, 'Student1918', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1919, 'Student1919', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1920, 'Student1920', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1921, 'Student1921', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1922, 'Student1922', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1923, 'Student1923', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1924, 'Student1924', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1925, 'Student1925', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1926, 'Student1926', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1927, 'Student1927', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1928, 'Student1928', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1929, 'Student1929', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1930, 'Student1930', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1931, 'Student1931', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1932, 'Student1932', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1933, 'Student1933', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1934, 'Student1934', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1935, 'Student1935', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1936, 'Student1936', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1937, 'Student1937', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1938, 'Student1938', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1939, 'Student1939', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1940, 'Student1940', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1941, 'Student1941', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1942, 'Student1942', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1943, 'Student1943', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1944, 'Student1944', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1945, 'Student1945', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1946, 'Student1946', 7);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1947, 'Student1947', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1948, 'Student1948', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1949, 'Student1949', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1950, 'Student1950', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1951, 'Student1951', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1952, 'Student1952', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1953, 'Student1953', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1954, 'Student1954', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1955, 'Student1955', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1956, 'Student1956', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1957, 'Student1957', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1958, 'Student1958', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1959, 'Student1959', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1960, 'Student1960', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1961, 'Student1961', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1962, 'Student1962', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1963, 'Student1963', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1964, 'Student1964', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1965, 'Student1965', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1966, 'Student1966', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1967, 'Student1967', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1968, 'Student1968', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1969, 'Student1969', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1970, 'Student1970', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1971, 'Student1971', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1972, 'Student1972', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1973, 'Student1973', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1974, 'Student1974', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1975, 'Student1975', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1976, 'Student1976', 5);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1977, 'Student1977', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1978, 'Student1978', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1979, 'Student1979', 8);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1980, 'Student1980', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1981, 'Student1981', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1982, 'Student1982', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1983, 'Student1983', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1984, 'Student1984', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1985, 'Student1985', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1986, 'Student1986', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1987, 'Student1987', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1988, 'Student1988', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1989, 'Student1989', 1);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1990, 'Student1990', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1991, 'Student1991', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1992, 'Student1992', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1993, 'Student1993', 3);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1994, 'Student1994', 2);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1995, 'Student1995', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1996, 'Student1996', 6);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1997, 'Student1997', 4);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1998, 'Student1998', 9);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (1999, 'Student1999', 10);

INSERT INTO Student (ID, name, dept_ID) VALUES
  (2000, 'Student2000', 3);


INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C1', 'Course1', 5, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C2', 'Course2', 3, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C3', 'Course3', 4, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C4', 'Course4', 1, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C5', 'Course5', 5, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C6', 'Course6', 4, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C7', 'Course7', 4, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C8', 'Course8', 2, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C9', 'Course9', 4, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C10', 'Course10', 5, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C11', 'Course11', 2, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C12', 'Course12', 1, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C13', 'Course13', 2, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C14', 'Course14', 5, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C15', 'Course15', 4, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C16', 'Course16', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C17', 'Course17', 1, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C18', 'Course18', 4, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C19', 'Course19', 5, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C20', 'Course20', 3, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C21', 'Course21', 1, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C22', 'Course22', 2, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C23', 'Course23', 2, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C24', 'Course24', 1, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C25', 'Course25', 5, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C26', 'Course26', 3, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C27', 'Course27', 5, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C28', 'Course28', 4, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C29', 'Course29', 2, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C30', 'Course30', 4, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C31', 'Course31', 4, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C32', 'Course32', 3, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C33', 'Course33', 2, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C34', 'Course34', 1, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C35', 'Course35', 2, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C36', 'Course36', 3, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C37', 'Course37', 1, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C38', 'Course38', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C39', 'Course39', 5, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C40', 'Course40', 1, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C41', 'Course41', 2, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C42', 'Course42', 5, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C43', 'Course43', 5, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C44', 'Course44', 2, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C45', 'Course45', 3, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C46', 'Course46', 5, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C47', 'Course47', 4, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C48', 'Course48', 2, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C49', 'Course49', 1, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C50', 'Course50', 5, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C51', 'Course51', 5, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C52', 'Course52', 4, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C53', 'Course53', 5, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C54', 'Course54', 2, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C55', 'Course55', 2, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C56', 'Course56', 4, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C57', 'Course57', 2, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C58', 'Course58', 4, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C59', 'Course59', 4, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C60', 'Course60', 5, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C61', 'Course61', 5, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C62', 'Course62', 3, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C63', 'Course63', 2, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C64', 'Course64', 2, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C65', 'Course65', 3, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C66', 'Course66', 1, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C67', 'Course67', 1, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C68', 'Course68', 1, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C69', 'Course69', 1, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C70', 'Course70', 3, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C71', 'Course71', 5, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C72', 'Course72', 5, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C73', 'Course73', 3, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C74', 'Course74', 2, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C75', 'Course75', 4, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C76', 'Course76', 2, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C77', 'Course77', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C78', 'Course78', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C79', 'Course79', 3, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C80', 'Course80', 3, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C81', 'Course81', 3, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C82', 'Course82', 4, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C83', 'Course83', 4, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C84', 'Course84', 2, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C85', 'Course85', 2, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C86', 'Course86', 3, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C87', 'Course87', 1, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C88', 'Course88', 3, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C89', 'Course89', 1, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C90', 'Course90', 2, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C91', 'Course91', 5, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C92', 'Course92', 4, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C93', 'Course93', 1, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C94', 'Course94', 5, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C95', 'Course95', 2, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C96', 'Course96', 4, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C97', 'Course97', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C98', 'Course98', 1, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C99', 'Course99', 4, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C100', 'Course100', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C101', 'Course101', 4, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C102', 'Course102', 4, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C103', 'Course103', 4, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C104', 'Course104', 2, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C105', 'Course105', 1, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C106', 'Course106', 2, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C107', 'Course107', 3, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C108', 'Course108', 4, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C109', 'Course109', 3, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C110', 'Course110', 1, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C111', 'Course111', 4, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C112', 'Course112', 1, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C113', 'Course113', 4, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C114', 'Course114', 3, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C115', 'Course115', 5, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C116', 'Course116', 4, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C117', 'Course117', 3, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C118', 'Course118', 3, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C119', 'Course119', 1, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C120', 'Course120', 4, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C121', 'Course121', 1, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C122', 'Course122', 1, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C123', 'Course123', 5, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C124', 'Course124', 4, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C125', 'Course125', 5, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C126', 'Course126', 5, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C127', 'Course127', 5, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C128', 'Course128', 1, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C129', 'Course129', 5, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C130', 'Course130', 4, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C131', 'Course131', 4, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C132', 'Course132', 4, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C133', 'Course133', 2, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C134', 'Course134', 2, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C135', 'Course135', 4, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C136', 'Course136', 4, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C137', 'Course137', 5, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C138', 'Course138', 4, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C139', 'Course139', 4, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C140', 'Course140', 5, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C141', 'Course141', 3, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C142', 'Course142', 2, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C143', 'Course143', 2, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C144', 'Course144', 3, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C145', 'Course145', 2, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C146', 'Course146', 1, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C147', 'Course147', 4, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C148', 'Course148', 5, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C149', 'Course149', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C150', 'Course150', 3, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C151', 'Course151', 3, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C152', 'Course152', 1, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C153', 'Course153', 4, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C154', 'Course154', 2, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C155', 'Course155', 3, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C156', 'Course156', 3, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C157', 'Course157', 3, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C158', 'Course158', 1, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C159', 'Course159', 3, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C160', 'Course160', 2, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C161', 'Course161', 1, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C162', 'Course162', 2, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C163', 'Course163', 3, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C164', 'Course164', 3, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C165', 'Course165', 3, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C166', 'Course166', 4, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C167', 'Course167', 1, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C168', 'Course168', 3, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C169', 'Course169', 2, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C170', 'Course170', 4, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C171', 'Course171', 4, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C172', 'Course172', 4, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C173', 'Course173', 5, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C174', 'Course174', 3, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C175', 'Course175', 2, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C176', 'Course176', 3, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C177', 'Course177', 3, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C178', 'Course178', 4, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C179', 'Course179', 3, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C180', 'Course180', 4, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C181', 'Course181', 4, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C182', 'Course182', 5, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C183', 'Course183', 2, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C184', 'Course184', 1, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C185', 'Course185', 1, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C186', 'Course186', 3, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C187', 'Course187', 1, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C188', 'Course188', 2, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C189', 'Course189', 2, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C190', 'Course190', 2, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C191', 'Course191', 5, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C192', 'Course192', 5, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C193', 'Course193', 1, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C194', 'Course194', 2, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C195', 'Course195', 1, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C196', 'Course196', 4, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C197', 'Course197', 3, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C198', 'Course198', 1, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C199', 'Course199', 1, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C200', 'Course200', 5, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C201', 'Course201', 4, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C202', 'Course202', 2, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C203', 'Course203', 4, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C204', 'Course204', 4, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C205', 'Course205', 1, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C206', 'Course206', 2, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C207', 'Course207', 3, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C208', 'Course208', 4, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C209', 'Course209', 1, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C210', 'Course210', 2, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C211', 'Course211', 5, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C212', 'Course212', 4, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C213', 'Course213', 3, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C214', 'Course214', 4, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C215', 'Course215', 4, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C216', 'Course216', 2, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C217', 'Course217', 4, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C218', 'Course218', 4, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C219', 'Course219', 4, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C220', 'Course220', 3, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C221', 'Course221', 2, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C222', 'Course222', 1, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C223', 'Course223', 5, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C224', 'Course224', 5, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C225', 'Course225', 4, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C226', 'Course226', 5, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C227', 'Course227', 5, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C228', 'Course228', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C229', 'Course229', 4, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C230', 'Course230', 2, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C231', 'Course231', 4, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C232', 'Course232', 5, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C233', 'Course233', 3, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C234', 'Course234', 5, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C235', 'Course235', 2, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C236', 'Course236', 1, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C237', 'Course237', 4, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C238', 'Course238', 5, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C239', 'Course239', 1, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C240', 'Course240', 4, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C241', 'Course241', 4, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C242', 'Course242', 5, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C243', 'Course243', 1, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C244', 'Course244', 5, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C245', 'Course245', 2, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C246', 'Course246', 4, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C247', 'Course247', 3, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C248', 'Course248', 1, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C249', 'Course249', 1, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C250', 'Course250', 2, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C251', 'Course251', 5, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C252', 'Course252', 4, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C253', 'Course253', 1, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C254', 'Course254', 2, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C255', 'Course255', 2, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C256', 'Course256', 3, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C257', 'Course257', 3, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C258', 'Course258', 1, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C259', 'Course259', 3, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C260', 'Course260', 4, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C261', 'Course261', 5, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C262', 'Course262', 4, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C263', 'Course263', 1, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C264', 'Course264', 1, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C265', 'Course265', 2, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C266', 'Course266', 1, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C267', 'Course267', 4, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C268', 'Course268', 2, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C269', 'Course269', 2, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C270', 'Course270', 2, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C271', 'Course271', 1, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C272', 'Course272', 1, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C273', 'Course273', 2, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C274', 'Course274', 1, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C275', 'Course275', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C276', 'Course276', 4, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C277', 'Course277', 3, 4);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C278', 'Course278', 4, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C279', 'Course279', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C280', 'Course280', 3, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C281', 'Course281', 3, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C282', 'Course282', 4, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C283', 'Course283', 1, 2);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C284', 'Course284', 4, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C285', 'Course285', 1, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C286', 'Course286', 5, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C287', 'Course287', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C288', 'Course288', 3, 6);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C289', 'Course289', 4, 3);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C290', 'Course290', 4, 1);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C291', 'Course291', 3, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C292', 'Course292', 4, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C293', 'Course293', 1, 8);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C294', 'Course294', 2, 5);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C295', 'Course295', 3, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C296', 'Course296', 2, 10);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C297', 'Course297', 5, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C298', 'Course298', 2, 9);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C299', 'Course299', 4, 7);

INSERT INTO Course (course_code, name, credit, offered_by_dept_ID) VALUES
  ('C300', 'Course300', 1, 8);

